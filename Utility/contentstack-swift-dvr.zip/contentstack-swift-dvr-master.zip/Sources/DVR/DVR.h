//
//  DVR.h
//  DVR
//
//  Created by Sam Soffes on 6/18/15.
//  Copyright © 2015 Venmo. All rights reserved.
//

@import Foundation;

//! Project version number for DVR.
FOUNDATION_EXPORT double DVRVersionNumber;

//! Project version string for DVR.
FOUNDATION_EXPORT const unsigned char DVRVersionString[];
